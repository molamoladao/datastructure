#include<iostream>
#include<stdlib.h> 
#include<iomanip>
#define max 100
using namespace std;
struct  tuple {
                 int i,j;
                 int v;
};
struct sparmattp{
	int m,n,t;
//m:����; n:����; t:����Ԫ����Ŀ}
	tuple data[max]; 
};
void init(struct sparmattp &M,int col,int row)
{
	M.m=col;
	M.n=row;
	M.t=0;
}
void add(struct sparmattp &M_1,struct sparmattp &M_2)
{
	int m_1_count=0,m_2_count=0;
	int t_count_1=1,t_count_2=1;
	int i,j,z;
	int pre; 
	int M_1_i,M_1_j,M_2_i,M_2_j;
/**************��M_2�ӵ�M_1��***************/ 
	pre=1;
	while(t_count_1<M_1.t||t_count_1==M_1.t
	&&t_count_2<M_2.t||t_count_2==M_2.t) 
	{
	   M_1_i=M_1.data[t_count_1].i;
	   M_1_j=M_1.data[t_count_1].j;
	   M_2_i=M_2.data[t_count_2].i;
	   M_2_j=M_2.data[t_count_2].j;
	   if(M_1_i<M_2_i||M_1_i==M_2_i&&M_1_j<M_2_j)
	   {
	      t_count_1++;
	      pre=t_count_1;
	   }
	   else if(M_1_i==M_2_i&&M_1_j==M_2_j)	
	   {
	      M_1.data[t_count_1].v=M_1.data[t_count_1].v+M_2.data[t_count_2].v;
	      t_count_1++;
	      t_count_2++;
	      pre=t_count_1;
	   }
	   else if(M_1_i>M_2_i)
	   {
	      for(z=M_1.t+1;z>=pre+1;z--)
	      {
	    	M_1.data[z]=M_1.data[z-1];
	      }
	      M_1.data[z]=M_2.data[t_count_2];//����M_2.data[i]
	      M_1.t++;
	      pre++;
	      t_count_1++;
	      t_count_2++;
	   }
	}
	if(t_count_2!=M_2.t+1)
	{
	  for(i=t_count_2,j=t_count_1;i<=M_2.t;i++,j++)
	  {
	      M_1.data[j]=M_2.data[i];//����M_2.data[i]	
	  }
	}
	 
}
void trans_sparmat(struct sparmattp &a,struct sparmattp &b)
{
    b.m=a.n;  b.n=a.m;  b.t=a.t;
    int q,col_1,p;
    col_1=1;
    if (b.t >0)
         {  q=1;        //ָʾb�д�����ݵ�λ�ã���ֵΪ1
            for (col_1=0; col_1<=a.n-1;col_1++)   //��aɨ��a.n��
                 for (p=1;p<=a.t;p++)      // ��a.t�����ݼ��
                      if (a.data[p].j==col_1)     // ���㵱ǰɨ���к�
                     {     b.data[q].i=a.data[p].j;// ��b��ֵ
                           b.data[q].j=a.data[p].i;
                           b.data[q].v=a.data[p].v;
                           q=q+1;              //    ����qֵ
                       }
          }
}
void multiple(struct sparmattp &a,struct sparmattp &b,struct sparmattp &c)
{
	int t_count_a=1;
	int t_count_b=1;
	int t_count_c=1;
	int key_a=1,key_b=1;
	int ii,jj,k,calculate;
	for(ii=0;ii<a.m;ii++)
	{
		for(jj=0;jj<b.m;jj++)/////b.n
		{
			calculate=0;
			if(a.data[t_count_a].i==ii&&
			b.data[t_count_b].i==jj)
			while(a.data[t_count_a].i==ii&&b.data[t_count_b].i==jj)
			{
				if(t_count_a<=a.t&&t_count_b<=b.t)
				{
				  if(a.data[t_count_a].j==b.data[t_count_b].j)
				{
				calculate=calculate+
				a.data[t_count_a].v*b.data[t_count_b].v;
				t_count_a++;
				t_count_b++;
				}
				else if(a.data[t_count_a].j>b.data[t_count_b].j)
				t_count_b++;
				else
				t_count_a++;
				}
			}
			c.data[t_count_c].i=ii;
			c.data[t_count_c].j=jj;
			c.data[t_count_c].v=calculate;
			if(calculate!=0)
			{
			c.t++;
			t_count_c++;
			 } 
			while(a.data[t_count_a].i==ii)
			t_count_a++;
			while(b.data[t_count_b].i==jj)
			t_count_b++;
			if(jj==b.m-1)
		          key_a=t_count_a;//����a������ 
		          
			t_count_a=key_a; ///ֱ�Ӿ� 
		}
		t_count_b=1;
		
		
	}
 } 
 void prit(struct sparmattp M)
 {
 	int i,j,t_count=1;
 	for(i=0;i<=M.m-1;i++)
 	{
 	    	for(j=0;j<=M.n-1;j++)
 	    	{
 	    	     if(M.data[t_count].i==i&&M.data[t_count].j==j)
 	    	     {
 	    	     	cout<<std::left<<setw(5)<<M.data[t_count].v;
 	    	     	t_count++; 
		     }
		     else 
		     	cout<<std::left<<setw(5)<<"0";
		    if(j==M.n-1)
		    cout<<endl;
 	    	     
		}
	}
 }
int main()
{
	int row,col,count,i,j,key,value;
	int t_count=1; 
	int matrix_1[col][row];
	int matrix_2[col][row];
	struct sparmattp M_1,M_2,M_3,M_4;
	struct tuple current;
	cout<<"Please enter the scale of the first matrix you want:"<<endl;
	cout<<"row(row>=1):"<<endl;
	cout<<"3"<<endl;
	cout<<"col(col>=1)"<<endl;
	cout<<"4"<<endl;
	cout<<"Please enter the first matrix:"<<endl;
	cout<<"1 0 1 0"<<endl;
	cout<<"0 0 0 0"<<endl;
	cout<<"0 1 0 0"<<endl;
	cout<<"If you didn't enter the statistics as the example, some errors may arise!"<<endl;
	
/*******************�����һ������************************/ 
	cout<<"Please enter the scale of the first matrix you want:"<<endl;
	cout<<"row(row>=1):"<<endl;	
	cin>>col;
	while(col<0||col==0)
	{
		cout<<"Enter again col(col>=1):"<<endl;
		cin>>col;	
	}
	cout<<"col(col>=1)"<<endl;
	cin>>row;
	while(row<0||row==0)
	{
		cout<<"Enter again row(row>=1):"<<endl;
		cin>>row;		
	}
	cout<<"Please enter the first matrix:"<<endl;
	init(M_1,col,row);
	for(i=0;i<col;i++)
		for(j=0;j<row;j++)
		{
			cin>>matrix_1[i][j];
			if(matrix_1[i][j]!=0)
			{
				M_1.data[t_count].i=i;
				M_1.data[t_count].j=j;
				M_1.data[t_count].v=matrix_1[i][j];
				t_count++;
			}			
	          }
	M_1.t=t_count-1; 
	
/********************����ڶ�������************************/ 
	cout<<"Please enter the scale of the second matrix you want:"<<endl;
	cout<<"row(row>=1):"<<endl;	
	cin>>col;
	while(col<0||col==0)
	{
		cout<<"Enter again row(row>=1):"<<endl;
		cin>>col;	
	}
	cout<<"col(col>=1)"<<endl;
	cin>>row;
	while(row<0||row==0)
	{
		cout<<"Enter again col(col>=1):"<<endl;
		cin>>row;		
	}    
	t_count=1; 
	init(M_2,col,row);
	cout<<"Please enter the second matrix:"<<endl;
	for(i=0;i<col;i++)
		for(j=0;j<row;j++)
		{
			cin>>matrix_1[i][j];
			if(matrix_1[i][j]!=0)
			{
				M_2.data[t_count].i=i;
				M_2.data[t_count].j=j;
				M_2.data[t_count].v=matrix_1[i][j];
				t_count++;
			}			
	          }
	M_2.t=t_count-1;

/******************������������мӷ��ͳ˷�*****************/ 
	if(M_1.m==M_2.m&&M_1.n==M_2.n)
	{
	  cout<<"The result of addition is:"<<endl; 
	  add(M_1,M_2);
	  prit(M_1);	
	}
	else
	cout<<"They can't operate addition "<<endl;
	init(M_3,M_2.m,M_2.n);
	init(M_4,M_1.m,M_2.n);
	//trans_sparmat(M_2,M_3);//M_3��M_2��ת�þ��� 
	if(M_1.n==M_2.m)
	{
	   cout<<"The result of multiplication is:"<<endl;
	   trans_sparmat(M_2,M_3);//M_3��M_2��ת�þ��� 
	   multiple(M_1,M_3,M_4);//M_4�� M_1*M_3�Ľ��   
	   prit(M_4);
	}         //�˴�if��������ûд�ꡣ 
	else
	  cout<<"They can't opeate multiplication "<<endl;
	 return 0; 	
} 


