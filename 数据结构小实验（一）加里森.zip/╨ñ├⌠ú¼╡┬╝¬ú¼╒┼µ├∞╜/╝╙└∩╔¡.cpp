#include<iostream>
#include<stdlib.h>
using namespace std;
struct member{
	int number;
	struct member *next;
};
int f(int n,int x);
struct member* create(int n);
void prit(struct member *head,int n,int x,int y);
void prit_1(struct member *head);
int main()
{
      	int n,x,y,right;
      	struct member *head,*head_1;
      	cout<<"Please input n(n>1,n is the total number of the sodiers):"<<endl;
      	cin>>n;
      	while(n<2)
      	{
      	cout<<"Attention, please!"<<" ";
	cout<<"Please input n(n>1,n is the total number of the sodiers):"<<endl;
      	cin>>n;
      	}
      	cout<<"Please input x(0<x<=n,we will start to count from the xth member):"<<endl;
      	cin>>x;
      	while(x<1||x>n)
      	{
      	cout<<"Attention, please!"<<" ";
      	cout<<"Please input x(0<x<=n-1,we will start to count from the xth member):"<<endl;
      	cin>>x;		
      	}
      	cout<<"Please input y(0<y<=n,y is the step):"<<endl;
      	cin>>y;
      	while(y<1||y>n)
      	{
      	cout<<"Attention, please!"<<" ";
      	cout<<"Please input y(0<y<=n,y is the step):"<<endl;
      	cin>>y;		
      	}
      	cout<<endl;
      	create(n);
      	head=create(n);
      	prit_1(head);
      	right=f(n,x);
      	if(y!=right)
          {
          	cout<<"According to the n,x,y that you have input,the order of death is:"<<endl;
		prit(head,n,x,y);
		cout<<endl;
		head_1=create(n);
		cout<<"According to the n,x that you have input,y should be:"<<right<<endl;
		cout<<"Then,the order of correct death:"<<endl;
		prit(head_1,n,x,right);
		cout<<endl;
          }
          else
          {
          	cout<<"According to the n,x,y you have input, the special man will be alive at last!"<<endl; 
		cout<<"The order of death(correct):"<<endl;
          	prit(head,n,x,y);
          	cout<<endl;
          }
          return 0;
      	
}
struct member* create(int n)
{
	int i;
	struct member *head=NULL,*last=NULL,*current;
	for(i=1;i<=n;i++)
	{
	      if(head==NULL)
	      {
	      	head=(struct member*)malloc(sizeof(struct member));
	      	head->next=head;
	      	head->number=i;
	      	last=head;
	      	last->next=head;
	      }	
	      else
	      {
	      	current=(struct member*)malloc(sizeof(struct member));
	      	last->next=current;
	      	current->next=head;
	      	current->number=i;
	      	last=current;
	      	last->next=head;
	      }
	}
	return head;
}
void prit_1(struct member *head)
{
	struct member *current;
	current=head;
	int flag=0; 
	cout<<"The number of all members:"<<endl;
	while(current->next!=current)
	{
		if(current==head)
		    flag++;
	          if(flag==2)
	             break;
		cout<<current->number<<" ";
		current=current->next;
	}
	cout<<endl;
	cout<<endl;
} 
void prit(struct member *head,int n,int x,int y)
{
	struct member *current_1,*last=NULL,*del;
	current_1=head;
	int count=1;
	int all=n;
	while(current_1->number!=x)
	{
		last=current_1;
		current_1=current_1->next;
	}	
	count=0;
	if(y!=1)
	{
		while(current_1->next!=current_1)
		{
		     if(count==y-1)
		     {
			del=current_1;
			cout<<current_1->number<<"->";
			last->next=current_1->next;
			current_1=current_1->next;
		     	free(del);
		     	count=0;
		     	all--;
		     }
		     else
		     {
			     last=current_1;
			     current_1=current_1->next; 
			     count=count+1;
		     }
		}
		cout<<current_1->number<<endl;
		free(current_1);
	}
	else if(y==1)
	{
		while(last->next!=last)
		{
			del=current_1;
			current_1=current_1->next;
			last->next=current_1;
			cout<<del->number<<"->";
			free(del); 
		}
		cout<<last->number<<endl;
		free(last);	
	}
}
int f(int n,int x)
{
	int y;
	for(y=1;y<=100;y++)
	{
	    int p=0;
	    for(int i=1;i<=n-1;i++)
	    {
	    	if(i!=n-1)
	    	p=(p+y)%(i+1);
	    	else
	    	p=(p+x+y-1)%n;	
	    }
	    if(p==0)
	    break;
	}
	return y;
}
