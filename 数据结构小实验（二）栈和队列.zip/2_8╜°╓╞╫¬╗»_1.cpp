#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
using namespace std;
#include<math.h>
#define error -1
#define MAXSIZE 100
#define max 10
typedef struct
{
	char *base;
	char *top;
	int stacksize;
}SqStack;
void InitStack(SqStack &S)
{
	S.base=(char*)malloc(MAXSIZE*sizeof(char));
	S.top=S.base;
	S.stacksize=MAXSIZE;
}//��ʼ��һ����ջ
int IsFull(SqStack &S)
{
	return(S.top-S.base==MAXSIZE);
}
int IsEmpty(SqStack &S)
{
	return(S.top==S.base);
}
int Push(SqStack &S,char e)
{

	if(IsFull(S))
	{
		exit(error);
	}
	*S.top++=e;
	return 1;	
}
int Pop(SqStack &S,char &e)
{
	if(IsEmpty(S))
	{
		exit(error);
	}
		e=*--S.top;	
	return 1;	
}
main()
{
	int i,j,key,N=0;
	char change;
	char e,ch='0';
	SqStack SS;
	SqStack SSS; 
	InitStack(SS);
	InitStack(SSS);
	printf("Enter a binary number:\n");
	for(i=0;ch!='#';i++)
	{
		ch=getchar();
		if(ch!='#') 
		Push(SS,ch);
	}
	key=1;
	N=0;
	while(!IsEmpty(SS))
	{
	if(key<=3)
	{
		Pop(SS,e);
		N=N+((int)e-48)*pow(2,key-1);
		key++;
	}
	else
	{
		change=N+48;
		Push(SSS,change);
		key=1;
		N=0;
	}
	}
	//N=N+((int)e-48)*pow(2,key-1);
	if(N!=0)
	change=N+48;
	Push(SSS,change);
    printf("According to the binary number to entered, the octal number is:\n");
	while(!IsEmpty(SSS))
	{
		Pop(SSS,e);
		cout<<e;
	} 
	return 0;
}
